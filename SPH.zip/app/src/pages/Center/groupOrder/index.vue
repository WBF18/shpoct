<template>
  <div>我是团购路由</div>
</template>

<script>
export default {

}
</script>

<style>

</style>